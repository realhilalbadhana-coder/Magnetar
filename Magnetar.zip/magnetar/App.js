import 'react-native-gesture-handler';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { BackHandler, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import ChatScreen from './src/screens/ChatScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import Sidebar from './src/components/Sidebar';
import { AUTO_MODEL_ID, getModel } from './src/config';
import { makeTitle } from './src/services/llm';
import { loadChats, saveChats, loadSettings, saveSettings } from './src/services/storage';
import { colors } from './src/theme';

const newId = () => 'c' + Date.now() + Math.floor(Math.random() * 1000);

export default function App() {
  const [ready, setReady] = useState(false);
  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [modelId, setModelId] = useState(AUTO_MODEL_ID);
  const [reasoning, setReasoning] = useState('medium');
  const [settings, setSettings] = useState({ webSearch: false });
  const [sidebar, setSidebar] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [pendingPrompt, setPendingPrompt] = useState(null);
  const chatsRef = useRef([]);

  // Load saved data
  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([loadChats(), loadSettings()]);
      setChats(c);
      chatsRef.current = c;
      if (s.modelId && getModel(s.modelId)) setModelId(s.modelId);
      if (s.reasoning) setReasoning(s.reasoning);
      setSettings({ webSearch: !!s.webSearch });
      setReady(true);
    })();
  }, []);

  // Persist
  useEffect(() => {
    if (!ready) return;
    chatsRef.current = chats;
    saveChats(chats);
  }, [chats, ready]);

  useEffect(() => {
    if (!ready) return;
    saveSettings({ ...settings, modelId, reasoning });
  }, [settings, modelId, reasoning, ready]);

  // Android back button
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (settingsOpen) { setSettingsOpen(false); return true; }
      if (sidebar) { setSidebar(false); return true; }
      return false;
    });
    return () => sub.remove();
  }, [sidebar, settingsOpen]);

  const activeChat = chats.find((c) => c.id === activeId) || null;

  // Chat update (naya chat bana deta hai agar pehle message par active nahi hai)
  const updateChat = useCallback(
    (patch, titleHint) => {
      setChats((prev) => {
        let id = activeId;
        let list = prev;
        if (!id || !prev.find((c) => c.id === id)) {
          id = newId();
          setActiveId(id);
          list = [{ id, title: makeTitle(titleHint), messages: [], pinned: false, updatedAt: Date.now() }, ...prev];
        }
        return list.map((c) =>
          c.id === id
            ? {
                ...c,
                ...patch,
                title: c.messages.length === 0 && titleHint ? makeTitle(titleHint) : c.title,
                updatedAt: Date.now(),
              }
            : c
        );
      });
    },
    [activeId]
  );

  const newChat = (promptText) => {
    setActiveId(null);
    setSidebar(false);
    if (typeof promptText === 'string') setTimeout(() => setPendingPrompt(promptText), 300);
  };

  const openChat = (id) => { setActiveId(id); setSidebar(false); };
  const pin = (id) => setChats((p) => p.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c)));
  const rename = (id, title) => setChats((p) => p.map((c) => (c.id === id ? { ...c, title } : c)));
  const del = (id) => {
    setChats((p) => p.filter((c) => c.id !== id));
    if (id === activeId) setActiveId(null);
  };

  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.bg }} />;

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <ChatScreen
        key={activeId || 'new'}
        chat={activeChat}
        modelId={modelId}
        onModelChange={setModelId}
        reasoning={reasoning}
        onReasoning={setReasoning}
        onOpenSidebar={() => setSidebar(true)}
        onUpdateChat={updateChat}
        settings={settings}
        onSettings={setSettings}
        pendingPrompt={pendingPrompt}
        clearPending={() => setPendingPrompt(null)}
      />
      <Sidebar
        visible={sidebar}
        onClose={() => setSidebar(false)}
        chats={chats}
        activeId={activeId}
        onOpenChat={openChat}
        onNewChat={newChat}
        onPin={pin}
        onRename={rename}
        onDelete={del}
        onOpenSettings={() => { setSidebar(false); setTimeout(() => setSettingsOpen(true), 250); }}
      />
      <SettingsScreen
        visible={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onSettings={setSettings}
      />
    </SafeAreaProvider>
  );
}
