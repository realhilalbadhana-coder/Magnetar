// Copilot-style warm beige theme
export const colors = {
  bg: '#F5F1ED',
  surface: '#FFFFFF',
  sheet: '#F5F0EC',
  chip: '#EDE6DF',
  chipDark: '#E5DBD2',
  card: '#E4E0DB',
  text: '#1F1B18',
  textMuted: '#6E645C',
  textFaint: '#9A8F86',
  border: '#E3DBD3',
  black: '#1F1B18',
  danger: '#A5234F',
  overlay: 'rgba(30, 27, 24, 0.45)',
  userBubble: '#E9E1D9',
};

export const radius = {
  pill: 999,
  card: 20,
  sheet: 32,
};
