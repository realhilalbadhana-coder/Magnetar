import React, { useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import BottomSheet from '../components/BottomSheet';
import { colors } from '../theme';

// Camera HALF SCREEN mein (Copilot jaisa) - bottom sheet ke andar live preview
export default function CameraSheet({ visible, onClose, onCaptured }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [facing, setFacing] = useState('back');
  const [flash, setFlash] = useState('off');
  const [busy, setBusy] = useState(false);
  const ref = useRef(null);

  const shoot = async () => {
    if (!ref.current || busy) return;
    setBusy(true);
    try {
      const photo = await ref.current.takePictureAsync({ quality: 0.6 });
      onCaptured(photo.uri);
    } catch {}
    setBusy(false);
  };

  return (
    <BottomSheet visible={visible} onClose={onClose} heightRatio={0.55}>
      {!permission?.granted ? (
        <View style={styles.perm}>
          <Text style={styles.permText}>Camera use karne ke liye permission chahiye</Text>
          <Pressable style={styles.permBtn} onPress={requestPermission}>
            <Text style={styles.permBtnText}>Allow camera</Text>
          </Pressable>
        </View>
      ) : (
        <View style={styles.wrap}>
          {visible ? (
            <CameraView ref={ref} style={StyleSheet.absoluteFill} facing={facing} flash={flash} />
          ) : null}

          <View style={styles.controls}>
            <Pressable style={styles.small} onPress={onClose}>
              <Text style={styles.smallText}>‹</Text>
            </Pressable>
            <Pressable style={styles.shutterOuter} onPress={shoot}>
              <View style={styles.shutter} />
            </Pressable>
            <View style={{ gap: 10 }}>
              <Pressable style={styles.small} onPress={() => setFlash(flash === 'off' ? 'on' : 'off')}>
                <Text style={styles.smallText}>{flash === 'off' ? '⚡✕' : '⚡'}</Text>
              </Pressable>
              <Pressable style={styles.small} onPress={() => setFacing(facing === 'back' ? 'front' : 'back')}>
                <Text style={styles.smallText}>⟳</Text>
              </Pressable>
            </View>
          </View>
        </View>
      )}
    </BottomSheet>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, borderRadius: 26, overflow: 'hidden', backgroundColor: '#000' },
  controls: {
    position: 'absolute', left: 0, right: 0, bottom: 14,
    flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', paddingHorizontal: 14,
  },
  small: {
    width: 46, height: 46, borderRadius: 23, backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center', justifyContent: 'center',
  },
  smallText: { color: '#fff', fontSize: 20, fontWeight: '700' },
  shutterOuter: {
    width: 84, height: 84, borderRadius: 42, backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center', justifyContent: 'center',
  },
  shutter: { width: 66, height: 66, borderRadius: 33, backgroundColor: '#fff' },
  perm: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16 },
  permText: { fontSize: 16, color: colors.text, textAlign: 'center' },
  permBtn: { backgroundColor: colors.black, paddingVertical: 12, paddingHorizontal: 26, borderRadius: 999 },
  permBtnText: { color: '#fff', fontWeight: '700' },
});
