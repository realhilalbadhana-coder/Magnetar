import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, FlatList, Image, KeyboardAvoidingView, Platform,
  Pressable, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';

import { Hamburger } from '../components/Icons';
import MessageBubble from '../components/MessageBubble';
import ModelPicker from '../components/ModelPicker';
import AttachSheet from '../components/AttachSheet';
import CameraSheet from './CameraSheet';
import { getModel, MODELS } from '../config';
import { askModel } from '../services/llm';
import { searchNews, resultsToContext } from '../services/search';
import { analyzeImage } from '../services/vision';
import { startRecording, stopAndTranscribe, cancelRecording } from '../services/voice';
import { colors, radius } from '../theme';

const SUGGESTIONS = [
  { label: 'Top news', text: 'Aaj ki top news kya hai?', search: true },
  { label: 'Topic mastery', text: 'Mujhe ek topic step-by-step master karwao. Pehle poocho ki kaunsa topic chahiye.' },
  { label: 'Plan with me', text: 'Mera aaj ka din plan karne mein help karo.' },
];

const TEXT_FILE_EXT = ['txt', 'md', 'json', 'csv', 'js', 'py', 'html', 'css', 'log', 'xml', 'yml', 'yaml'];

export default function ChatScreen({
  chat, modelId, onModelChange, reasoning, onReasoning,
  onOpenSidebar, onUpdateChat, settings, onSettings, pendingPrompt, clearPending,
}) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [attachOpen, setAttachOpen] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [image, setImage] = useState(null);       // {uri}
  const [fileCtx, setFileCtx] = useState(null);   // {name, text}
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const listRef = useRef(null);
  const abortRef = useRef(null);

  const model = getModel(modelId);
  const messages = chat?.messages || [];
  const hasText = input.trim().length > 0 || !!image || !!fileCtx;

  useEffect(() => {
    if (messages.length) setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 80);
  }, [messages.length, loading]);

  // Sidebar (Learn) se aaya hua prompt
  useEffect(() => {
    if (pendingPrompt) {
      send(pendingPrompt);
      clearPending();
    }
  }, [pendingPrompt]);

  // ---------- Attachments ----------
  const pickPhoto = async () => {
    setAttachOpen(false);
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return;
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.6 });
    if (!r.canceled) setImage({ uri: r.assets[0].uri });
  };

  const pickFile = async () => {
    setAttachOpen(false);
    const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true });
    if (r.canceled) return;
    const f = r.assets[0];
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    if (['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
      setImage({ uri: f.uri });
      return;
    }
    if (TEXT_FILE_EXT.includes(ext)) {
      try {
        const text = await FileSystem.readAsStringAsync(f.uri);
        setFileCtx({ name: f.name, text: text.slice(0, 12000) });
      } catch {
        setFileCtx({ name: f.name, text: '' });
      }
    } else {
      setFileCtx({ name: f.name, text: '' , unsupported: true });
    }
  };

  const openCamera = () => {
    setAttachOpen(false);
    setTimeout(() => setCameraOpen(true), 260);
  };

  // ---------- Voice ----------
  const toggleMic = async () => {
    try {
      if (!recording) {
        await startRecording();
        setRecording(true);
      } else {
        setRecording(false);
        setTranscribing(true);
        const text = await stopAndTranscribe();
        if (text) setInput((p) => (p ? p + ' ' : '') + text);
        setTranscribing(false);
      }
    } catch (e) {
      setRecording(false);
      setTranscribing(false);
      await cancelRecording();
      pushError(e.message);
    }
  };

  const pushError = (msg) => {
    const base = chat?.messages || [];
    onUpdateChat({
      messages: [...base, { id: 'e' + Date.now(), role: 'assistant', content: msg, error: true, modelName: model.name }],
    });
  };

  // ---------- Send ----------
  const send = async (overrideText, forceSearch) => {
    if (loading) return;
    const text = (overrideText ?? input).trim();
    if (!text && !image && !fileCtx) return;

    const userMsg = {
      id: 'u' + Date.now(),
      role: 'user',
      content: text || (image ? 'Is image ko analyze karo.' : ''),
      image: image?.uri,
      fileName: fileCtx?.name,
    };
    const history = [...messages, userMsg];
    onUpdateChat({ messages: history }, text || 'Image chat');

    const sentImage = image;
    const sentFile = fileCtx;
    setInput('');
    setImage(null);
    setFileCtx(null);
    setLoading(true);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      let reply = '';
      let sources = [];

      if (sentImage) {
        // Vision - Pollinations
        reply = await analyzeImage(sentImage.uri, userMsg.content);
      } else {
        let extraSystem = '';

        if (sentFile) {
          extraSystem += sentFile.unsupported
            ? `User ne "${sentFile.name}" file bheji hai jo padhi nahi ja sakti. User ko batao ki abhi sirf text files (txt, md, json, csv, code) support hain.`
            : `User ne file "${sentFile.name}" attach ki hai. Content:\n\n${sentFile.text}`;
        }

        // Web search
        if (settings.webSearch || forceSearch) {
          try {
            sources = await searchNews(text);
            const ctx = resultsToContext(text, sources);
            if (ctx) extraSystem += (extraSystem ? '\n\n' : '') + ctx;
          } catch (e) {
            extraSystem += '\n\n(Web search abhi fail hui, apne knowledge se jawab do aur user ko batao.)';
          }
        }

        reply = await askModel({
          modelId,
          messages: history,
          reasoning,
          extraSystem,
          signal: controller.signal,
        });
      }

      onUpdateChat({
        messages: [
          ...history,
          { id: 'a' + Date.now(), role: 'assistant', content: reply, modelName: sentImage ? 'Vision' : model.name, sources },
        ],
      });
    } catch (e) {
      if (e.name !== 'AbortError') {
        onUpdateChat({
          messages: [
            ...history,
            { id: 'e' + Date.now(), role: 'assistant', content: e.message || 'Kuch galat ho gaya.', error: true, modelName: model.name },
          ],
        });
      }
    }
    setLoading(false);
    abortRef.current = null;
  };

  const stop = () => abortRef.current?.abort();

  // ---------- UI ----------
  const isEmpty = messages.length === 0;

  return (
    <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={onOpenSidebar} style={styles.headerSide} hitSlop={10}>
          <Hamburger />
        </Pressable>
        <Pressable onPress={() => setPickerOpen(true)} style={styles.modelBtn}>
          <Text style={styles.modelText}>{model.name}</Text>
          <Text style={styles.chev}> ⌄</Text>
        </Pressable>
        <View style={styles.headerSide} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {isEmpty ? (
          <View style={styles.emptyWrap}>
            <Text style={styles.greet}>Hi, how's it going?</Text>
            <View style={{ alignItems: 'flex-start', gap: 12, marginTop: 20 }}>
              {SUGGESTIONS.map((s) => (
                <Pressable
                  key={s.label}
                  style={styles.chip}
                  onPress={() => send(s.text, s.search)}
                >
                  <Text style={styles.chipText}>{s.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : (
          <FlatList
            ref={listRef}
            data={messages}
            keyExtractor={(m) => m.id}
            contentContainerStyle={{ padding: 18, paddingBottom: 12 }}
            renderItem={({ item }) => <MessageBubble message={item} modelName={model.name} />}
            ListFooterComponent={
              loading ? (
                <View style={styles.typing}>
                  <ActivityIndicator color={colors.textMuted} />
                  <Text style={styles.typingText}>{model.name} soch raha hai…</Text>
                </View>
              ) : null
            }
          />
        )}

        {/* Input card */}
        <View style={styles.inputCard}>
          {image ? (
            <View style={styles.previewRow}>
              <View>
                <Image source={{ uri: image.uri }} style={styles.thumb} />
                <Pressable style={styles.thumbX} onPress={() => setImage(null)}>
                  <Text style={styles.thumbXText}>✕</Text>
                </Pressable>
              </View>
            </View>
          ) : null}
          {fileCtx ? (
            <View style={styles.fileChip}>
              <Text style={styles.fileText} numberOfLines={1}>📄 {fileCtx.name}</Text>
              <Pressable onPress={() => setFileCtx(null)}><Text style={styles.thumbXText2}>✕</Text></Pressable>
            </View>
          ) : null}

          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder={recording ? 'Sun raha hoon… (stop dabao)' : transcribing ? 'Likh raha hoon…' : 'Message Magnetar'}
            placeholderTextColor={colors.textFaint}
            style={styles.input}
            multiline
            maxLength={8000}
          />

          <View style={styles.inputBottom}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Pressable onPress={() => setAttachOpen(true)} style={styles.iconBtn} hitSlop={8}>
                <Text style={styles.plus}>+</Text>
              </Pressable>
              <Pressable
                onPress={() => onSettings({ ...settings, webSearch: !settings.webSearch })}
                style={[styles.globe, settings.webSearch && styles.globeOn]}
                hitSlop={8}
              >
                <Text style={{ fontSize: 16 }}>🌐</Text>
                {settings.webSearch ? <Text style={styles.globeText}>Search</Text> : null}
              </Pressable>
            </View>

            {loading ? (
              <Pressable style={styles.sendBtn} onPress={stop}>
                <Text style={styles.sendText}>■</Text>
              </Pressable>
            ) : hasText ? (
              <Pressable style={styles.sendBtn} onPress={() => send()}>
                <Text style={styles.sendText}>↑</Text>
              </Pressable>
            ) : (
              <Pressable
                style={[styles.sendBtn, recording && { backgroundColor: colors.danger }]}
                onPress={toggleMic}
                disabled={transcribing}
              >
                {transcribing ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.sendText}>{recording ? '■' : '🎙'}</Text>
                )}
              </Pressable>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>

      <ModelPicker
        visible={pickerOpen}
        onClose={() => setPickerOpen(false)}
        selectedId={modelId}
        onSelect={(id) => {
          onModelChange(id);
          const m = getModel(id);
          if (!m.reasoningLevels) setPickerOpen(false);
        }}
        reasoning={reasoning}
        onReasoning={(r) => { onReasoning(r); setPickerOpen(false); }}
      />
      <AttachSheet
        visible={attachOpen}
        onClose={() => setAttachOpen(false)}
        onCamera={openCamera}
        onPhoto={pickPhoto}
        onFile={pickFile}
      />
      <CameraSheet
        visible={cameraOpen}
        onClose={() => setCameraOpen(false)}
        onCaptured={(uri) => { setCameraOpen(false); setImage({ uri }); }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingVertical: 12 },
  headerSide: { width: 44 },
  modelBtn: { flexDirection: 'row', alignItems: 'center' },
  modelText: { fontSize: 22, fontWeight: '700', color: colors.text },
  chev: { fontSize: 18, color: colors.text },
  emptyWrap: { flex: 1, justifyContent: 'flex-end', paddingHorizontal: 22, paddingBottom: 26 },
  greet: { fontSize: 38, fontWeight: '800', color: colors.text, letterSpacing: -1 },
  chip: { backgroundColor: colors.chip, paddingVertical: 14, paddingHorizontal: 22, borderRadius: radius.pill },
  chipText: { fontSize: 18, color: colors.text },
  typing: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12 },
  typingText: { color: colors.textMuted, fontSize: 14 },
  inputCard: {
    backgroundColor: colors.surface, marginHorizontal: 14, marginBottom: 10,
    borderRadius: 32, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 12,
    elevation: 3, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 2 },
  },
  previewRow: { flexDirection: 'row', marginBottom: 8 },
  thumb: { width: 76, height: 76, borderRadius: 18 },
  thumbX: {
    position: 'absolute', top: -6, right: -6, width: 26, height: 26, borderRadius: 13,
    backgroundColor: '#5B534D', alignItems: 'center', justifyContent: 'center',
  },
  thumbXText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  thumbXText2: { color: colors.textMuted, fontSize: 15, paddingLeft: 10 },
  fileChip: {
    flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start',
    backgroundColor: colors.chip, borderRadius: 14, paddingVertical: 8, paddingHorizontal: 12, marginBottom: 8, maxWidth: '90%',
  },
  fileText: { fontSize: 14, color: colors.text },
  input: { fontSize: 18, color: colors.text, maxHeight: 130, paddingVertical: 6, paddingHorizontal: 4 },
  inputBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 },
  iconBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  plus: { fontSize: 32, color: colors.text, marginTop: -4 },
  globe: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 36, borderRadius: 18 },
  globeOn: { backgroundColor: colors.chip },
  globeText: { fontSize: 14, fontWeight: '600', color: colors.text },
  sendBtn: { width: 58, height: 58, borderRadius: 29, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' },
  sendText: { color: '#fff', fontSize: 26, fontWeight: '700' },
});
