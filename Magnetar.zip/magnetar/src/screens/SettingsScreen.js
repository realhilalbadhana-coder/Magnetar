import React, { useEffect, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PROVIDERS } from '../config';
import { getKey, saveKey } from '../services/storage';
import { colors, radius } from '../theme';

export default function SettingsScreen({ visible, onClose, settings, onSettings }) {
  const [values, setValues] = useState({});
  const [show, setShow] = useState({});

  useEffect(() => {
    if (!visible) return;
    (async () => {
      const v = {};
      for (const p of Object.values(PROVIDERS)) v[p.keyName] = await getKey(p.keyName);
      setValues(v);
    })();
  }, [visible]);

  const save = async () => {
    for (const p of Object.values(PROVIDERS)) await saveKey(p.keyName, values[p.keyName]);
    Alert.alert('Saved ✓', 'API keys phone ke secure storage mein save ho gayi.');
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={styles.root}>
        <View style={styles.header}>
          <Pressable onPress={onClose} style={styles.back}><Text style={styles.backText}>✕</Text></Pressable>
          <Text style={styles.title}>Settings</Text>
          <Pressable onPress={save} style={styles.saveBtn}><Text style={styles.saveText}>Save</Text></Pressable>
        </View>

        <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
          <Text style={styles.section}>API Keys</Text>
          <Text style={styles.note}>
            Keys sirf tere phone mein (encrypted) save hoti hain. Kabhi GitHub ya code mein mat daalo.
          </Text>

          {Object.values(PROVIDERS).map((p) => (
            <View key={p.id} style={styles.field}>
              <Text style={styles.label}>{p.label}</Text>
              <View style={styles.inputRow}>
                <TextInput
                  value={values[p.keyName] || ''}
                  onChangeText={(t) => setValues((v) => ({ ...v, [p.keyName]: t }))}
                  placeholder={p.hint}
                  placeholderTextColor={colors.textFaint}
                  secureTextEntry={!show[p.id]}
                  autoCapitalize="none"
                  autoCorrect={false}
                  style={styles.input}
                />
                <Pressable onPress={() => setShow((s) => ({ ...s, [p.id]: !s[p.id] }))}>
                  <Text style={styles.eye}>{show[p.id] ? '🙈' : '👁'}</Text>
                </Pressable>
              </View>
            </View>
          ))}

          <Text style={[styles.section, { marginTop: 26 }]}>Features</Text>
          <View style={styles.switchRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Web search</Text>
              <Text style={styles.note}>Live news/web se jawab (Google News)</Text>
            </View>
            <Switch
              value={!!settings.webSearch}
              onValueChange={(v) => onSettings({ ...settings, webSearch: v })}
              trackColor={{ true: colors.black }}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingVertical: 10 },
  back: { padding: 10 },
  backText: { fontSize: 22, color: colors.text },
  title: { fontSize: 20, fontWeight: '700', color: colors.text },
  saveBtn: { backgroundColor: colors.black, paddingVertical: 10, paddingHorizontal: 22, borderRadius: radius.pill },
  saveText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  section: { fontSize: 22, fontWeight: '800', color: colors.text, marginBottom: 6 },
  note: { fontSize: 13, color: colors.textMuted, marginBottom: 12, lineHeight: 19 },
  field: { marginBottom: 16 },
  label: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 6 },
  inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: 16, paddingHorizontal: 14 },
  input: { flex: 1, paddingVertical: 14, fontSize: 15, color: colors.text },
  eye: { fontSize: 20, paddingLeft: 10 },
  switchRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: 16, padding: 14 },
});
