import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import BottomSheet from './BottomSheet';
import { MODELS } from '../config';
import { colors, radius } from '../theme';

export default function ModelPicker({ visible, onClose, selectedId, onSelect, reasoning, onReasoning }) {
  const selected = MODELS.find((m) => m.id === selectedId);

  return (
    <BottomSheet visible={visible} onClose={onClose} heightRatio={0.62}>
      <Text style={styles.title}>Choose model</Text>
      <ScrollView showsVerticalScrollIndicator={false}>
        {MODELS.map((m) => {
          const active = m.id === selectedId;
          return (
            <Pressable
              key={m.id}
              onPress={() => onSelect(m.id)}
              style={[styles.row, active && styles.rowActive]}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{m.name}</Text>
                <Text style={styles.tag}>{m.tagline}</Text>
              </View>
              {active ? <Text style={styles.check}>✓</Text> : null}
            </Pressable>
          );
        })}

        {selected?.reasoningLevels ? (
          <View style={{ marginTop: 14 }}>
            <Text style={styles.sub}>Reasoning depth</Text>
            <View style={styles.levels}>
              {selected.reasoningLevels.map((lvl) => {
                const on = lvl === reasoning;
                return (
                  <Pressable
                    key={lvl}
                    onPress={() => onReasoning(lvl)}
                    style={[styles.level, on && styles.levelOn]}
                  >
                    <Text style={[styles.levelText, on && { color: '#fff' }]}>
                      {lvl[0].toUpperCase() + lvl.slice(1)}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}
      </ScrollView>
    </BottomSheet>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 12 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.chip,
    borderRadius: radius.card,
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  rowActive: { backgroundColor: colors.chipDark, borderWidth: 1.5, borderColor: colors.black },
  name: { fontSize: 16, fontWeight: '600', color: colors.text },
  tag: { fontSize: 13, color: colors.textMuted, marginTop: 2 },
  check: { fontSize: 20, color: colors.text, fontWeight: '700' },
  sub: { fontSize: 14, color: colors.textMuted, marginBottom: 8, fontWeight: '600' },
  levels: { flexDirection: 'row', gap: 10 },
  level: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderRadius: radius.pill,
    backgroundColor: colors.chip,
  },
  levelOn: { backgroundColor: colors.black },
  levelText: { fontSize: 15, fontWeight: '600', color: colors.text },
});
