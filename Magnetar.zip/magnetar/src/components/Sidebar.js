import React, { useEffect, useRef, useState } from 'react';
import {
  Animated, Dimensions, FlatList, Modal, Pressable, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from './Icons';
import { colors, radius } from '../theme';

const { width: W } = Dimensions.get('window');
const DRAWER_W = Math.min(W * 0.83, 340);

export default function Sidebar({
  visible, onClose, chats, activeId, onOpenChat, onNewChat,
  onPin, onRename, onDelete, onOpenSettings, onSearchTab,
}) {
  const slide = useRef(new Animated.Value(-DRAWER_W)).current;
  const [menuFor, setMenuFor] = useState(null);   // chat jiska menu khula hai
  const [renaming, setRenaming] = useState(null); // {id, title}
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    Animated.timing(slide, {
      toValue: visible ? 0 : -DRAWER_W,
      duration: 230,
      useNativeDriver: true,
    }).start();
    if (!visible) {
      setMenuFor(null);
      setSearching(false);
      setQuery('');
    }
  }, [visible]);

  const sorted = [...chats]
    .filter((c) => !query || c.title.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || b.updatedAt - a.updatedAt);

  const NavItem = ({ icon, label, active, onPress }) => (
    <Pressable onPress={onPress} style={[styles.nav, active && styles.navActive]}>
      <Icon name={icon} size={22} />
      <Text style={styles.navText}>{label}</Text>
    </Pressable>
  );

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose} statusBarTranslucent>
      <Pressable style={styles.overlay} onPress={onClose} />
      <Animated.View style={[styles.drawer, { width: DRAWER_W, transform: [{ translateX: slide }] }]}>
        <SafeAreaView style={{ flex: 1 }}>
          <View style={styles.top}>
            <Text style={styles.logo}>Magnetar</Text>
            <Pressable onPress={onOpenSettings} style={styles.gear}>
              <Icon name="settings" size={22} />
            </Pressable>
          </View>

          <NavItem icon="chat" label="Chat" active={!searching} onPress={() => setSearching(false)} />
          <NavItem
            icon="search"
            label="Search"
            active={searching}
            onPress={() => setSearching(true)}
          />
          {searching ? (
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Search chats…"
              placeholderTextColor={colors.textFaint}
              style={styles.search}
              autoFocus
            />
          ) : null}
          <NavItem icon="learn" label="Learn" onPress={() => { onNewChat('Mujhe aaj kuch naya sikhao. Ek interesting topic chuno aur simple tareeke se samjhao.'); }} />
          <NavItem icon="library" label="Library" onPress={() => setSearching(true)} />

          <Text style={styles.section}>Chats</Text>
          <FlatList
            data={sorted}
            keyExtractor={(c) => c.id}
            style={{ flex: 1 }}
            ListEmptyComponent={<Text style={styles.empty}>Abhi koi chat nahi hai</Text>}
            renderItem={({ item }) => (
              <View>
                <Pressable
                  onPress={() => onOpenChat(item.id)}
                  onLongPress={() => setMenuFor(item.id)}
                  style={[styles.chat, item.id === activeId && styles.chatActive]}
                >
                  <Text style={styles.chatTitle} numberOfLines={1}>
                    {item.pinned ? '📌 ' : ''}{item.title}
                  </Text>
                  <Pressable hitSlop={10} onPress={() => setMenuFor(menuFor === item.id ? null : item.id)}>
                    <Text style={styles.dots}>⋯</Text>
                  </Pressable>
                </Pressable>

                {menuFor === item.id ? (
                  <View style={styles.menu}>
                    <Pressable style={styles.menuRow} onPress={() => { onPin(item.id); setMenuFor(null); }}>
                      <Icon name="pin" size={20} />
                      <Text style={styles.menuText}>{item.pinned ? 'Unpin' : 'Pin'}</Text>
                    </Pressable>
                    <Pressable
                      style={styles.menuRow}
                      onPress={() => { setRenaming({ id: item.id, title: item.title }); setMenuFor(null); }}
                    >
                      <Icon name="rename" size={20} />
                      <Text style={styles.menuText}>Rename</Text>
                    </Pressable>
                    <Pressable style={styles.menuRow} onPress={() => { onDelete(item.id); setMenuFor(null); }}>
                      <Icon name="trash" size={20} />
                      <Text style={[styles.menuText, { color: colors.danger }]}>Delete</Text>
                    </Pressable>
                  </View>
                ) : null}
              </View>
            )}
          />

          <View style={styles.bottom}>
            <View style={styles.profile}>
              <View style={styles.avatar}><Text style={styles.avatarText}>M</Text></View>
              <View>
                <Text style={styles.pName}>Magnetar</Text>
                <Text style={styles.pSub}>Personal</Text>
              </View>
            </View>
            <Pressable style={styles.fab} onPress={() => onNewChat()}>
              <Text style={styles.fabText}>✎</Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </Animated.View>

      {/* Rename dialog */}
      <Modal visible={!!renaming} transparent animationType="fade" onRequestClose={() => setRenaming(null)}>
        <View style={styles.dialogOverlay}>
          <View style={styles.dialog}>
            <Text style={styles.dialogTitle}>Rename chat</Text>
            <TextInput
              value={renaming?.title || ''}
              onChangeText={(t) => setRenaming((r) => ({ ...r, title: t }))}
              style={styles.dialogInput}
              autoFocus
              maxLength={60}
            />
            <View style={styles.dialogBtns}>
              <Pressable onPress={() => setRenaming(null)} style={styles.dBtn}>
                <Text style={styles.dBtnText}>Cancel</Text>
              </Pressable>
              <Pressable
                onPress={() => {
                  if (renaming?.title.trim()) onRename(renaming.id, renaming.title.trim());
                  setRenaming(null);
                }}
                style={[styles.dBtn, { backgroundColor: colors.black }]}
              >
                <Text style={[styles.dBtnText, { color: '#fff' }]}>Save</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.overlay },
  drawer: {
    position: 'absolute', top: 0, bottom: 0, left: 0,
    backgroundColor: colors.bg, paddingHorizontal: 12,
  },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10, paddingHorizontal: 6 },
  logo: { fontSize: 30, fontWeight: '800', color: colors.text, letterSpacing: -1 },
  gear: { padding: 8 },
  nav: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingVertical: 14, paddingHorizontal: 16, borderRadius: 20 },
  navActive: { backgroundColor: '#E4DFDA' },
  navText: { fontSize: 20, color: colors.text },
  search: {
    backgroundColor: colors.surface, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 10,
    fontSize: 16, color: colors.text, marginVertical: 8,
  },
  section: { fontSize: 15, fontWeight: '700', color: colors.textMuted, marginTop: 22, marginBottom: 6, paddingHorizontal: 10 },
  empty: { color: colors.textFaint, paddingHorizontal: 10, paddingVertical: 12, fontSize: 15 },
  chat: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 10, borderRadius: 16 },
  chatActive: { backgroundColor: '#E9E4DF' },
  chatTitle: { flex: 1, fontSize: 18, color: colors.text },
  dots: { fontSize: 22, color: colors.textMuted, paddingHorizontal: 6 },
  menu: {
    backgroundColor: '#FBFAF9', borderRadius: 22, padding: 8, marginHorizontal: 6, marginBottom: 8,
    elevation: 6, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 12, shadowOffset: { width: 0, height: 4 },
  },
  menuRow: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, paddingHorizontal: 14 },
  menuText: { fontSize: 19, color: colors.text },
  bottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, paddingHorizontal: 4 },
  profile: {
    flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#E6DDD4',
    borderRadius: radius.pill, paddingVertical: 8, paddingLeft: 8, paddingRight: 22,
  },
  avatar: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#7A7570', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  pName: { fontSize: 18, color: colors.text },
  pSub: { fontSize: 14, color: colors.textMuted },
  fab: { width: 68, height: 68, borderRadius: 34, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' },
  fabText: { color: '#fff', fontSize: 28 },
  dialogOverlay: { flex: 1, backgroundColor: colors.overlay, alignItems: 'center', justifyContent: 'center', padding: 24 },
  dialog: { width: '100%', backgroundColor: colors.bg, borderRadius: 24, padding: 20 },
  dialogTitle: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 12 },
  dialogInput: { backgroundColor: colors.surface, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 17, color: colors.text },
  dialogBtns: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10, marginTop: 16 },
  dBtn: { paddingVertical: 10, paddingHorizontal: 22, borderRadius: radius.pill, backgroundColor: colors.chip },
  dBtnText: { fontSize: 16, fontWeight: '600', color: colors.text },
});
