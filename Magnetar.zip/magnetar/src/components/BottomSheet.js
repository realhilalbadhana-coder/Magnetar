import React, { useEffect, useRef } from 'react';
import { Animated, Dimensions, Modal, Pressable, StyleSheet, View } from 'react-native';
import { colors, radius } from '../theme';

const { height: H } = Dimensions.get('window');

// Half-screen tak ka bottom sheet (Copilot style, upar handle bar)
export default function BottomSheet({ visible, onClose, children, heightRatio = 0.5 }) {
  const slide = useRef(new Animated.Value(H)).current;
  const sheetH = H * heightRatio;

  useEffect(() => {
    Animated.timing(slide, {
      toValue: visible ? 0 : H,
      duration: 240,
      useNativeDriver: true,
    }).start();
  }, [visible]);

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose} statusBarTranslucent>
      <Pressable style={styles.overlay} onPress={onClose} />
      <Animated.View style={[styles.sheet, { height: sheetH, transform: [{ translateY: slide }] }]}>
        <View style={styles.handle} />
        {children}
      </Animated.View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.overlay },
  sheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.sheet,
    borderTopLeftRadius: radius.sheet,
    borderTopRightRadius: radius.sheet,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 24,
  },
  handle: {
    alignSelf: 'center',
    width: 64,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#7A727C',
    marginBottom: 18,
  },
});
