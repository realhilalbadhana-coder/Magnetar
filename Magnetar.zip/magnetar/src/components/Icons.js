// Simple icons - bina extra library ke (Text/View se)
import React from 'react';
import { Text, View } from 'react-native';
import { colors } from '../theme';

export const Icon = ({ name, size = 22, color = colors.text }) => {
  const map = {
    camera: '📷',
    photo: '🖼️',
    file: '📄',
    plus: '+',
    send: '↑',
    mic: '🎙',
    stop: '■',
    chat: '💬',
    search: '🔍',
    learn: '🎓',
    library: '📚',
    pin: '📌',
    rename: '✏️',
    trash: '🗑',
    check: '✓',
    close: '✕',
    chevron: '⌄',
    globe: '🌐',
    copy: '⧉',
    settings: '⚙️',
    newchat: '✎',
  };
  return <Text style={{ fontSize: size, color, lineHeight: size + 4 }}>{map[name] || '?'}</Text>;
};

// Hamburger (3 lines, Copilot jaisa)
export const Hamburger = ({ color = colors.text }) => (
  <View style={{ width: 26, gap: 5 }}>
    <View style={{ height: 2, backgroundColor: color, width: 26, borderRadius: 1 }} />
    <View style={{ height: 2, backgroundColor: color, width: 20, borderRadius: 1 }} />
    <View style={{ height: 2, backgroundColor: color, width: 26, borderRadius: 1 }} />
  </View>
);
