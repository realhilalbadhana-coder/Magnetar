import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import BottomSheet from './BottomSheet';
import { Icon } from './Icons';
import { colors, radius } from '../theme';

// Camera / Photo / File - half screen bottom sheet (Copilot jaisa)
export default function AttachSheet({ visible, onClose, onCamera, onPhoto, onFile }) {
  const Item = ({ icon, label, onPress }) => (
    <Pressable style={styles.item} onPress={onPress}>
      <Icon name={icon} size={28} />
      <Text style={styles.label}>{label}</Text>
    </Pressable>
  );

  return (
    <BottomSheet visible={visible} onClose={onClose} heightRatio={0.5}>
      <View style={styles.row}>
        <Item icon="camera" label="Camera" onPress={onCamera} />
        <Item icon="photo" label="Photo" onPress={onPhoto} />
        <Item icon="file" label="File" onPress={onFile} />
      </View>
    </BottomSheet>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: 12, marginTop: 6 },
  item: {
    flex: 1,
    height: 100,
    backgroundColor: '#E6DDD4',
    borderRadius: radius.card,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  label: { fontSize: 15, fontWeight: '700', color: colors.text },
});
