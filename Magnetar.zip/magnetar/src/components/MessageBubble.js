import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { colors } from '../theme';

// **bold** ko render karo (simple markdown)
function renderRich(text, style) {
  const parts = String(text).split(/(\*\*[^*]+\*\*)/g);
  return (
    <Text style={style} selectable>
      {parts.map((p, i) =>
        p.startsWith('**') && p.endsWith('**') ? (
          <Text key={i} style={{ fontWeight: '700' }}>
            {p.slice(2, -2)}
          </Text>
        ) : (
          <Text key={i}>{p}</Text>
        )
      )}
    </Text>
  );
}

export default function MessageBubble({ message, modelName }) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <View style={styles.userWrap}>
        <View style={styles.userBubble}>
          {message.image ? <Image source={{ uri: message.image }} style={styles.img} /> : null}
          {message.content ? renderRich(message.content, styles.userText) : null}
        </View>
      </View>
    );
  }

  return (
    <View style={styles.aiWrap}>
      <Text style={styles.aiName}>{message.modelName || modelName}</Text>
      {message.error ? (
        <Text style={styles.errorText} selectable>
          ⚠️ {message.content}
        </Text>
      ) : (
        renderRich(message.content, styles.aiText)
      )}
      {message.sources?.length ? (
        <View style={styles.sources}>
          <Text style={styles.sourcesTitle}>🌐 Sources</Text>
          {message.sources.slice(0, 4).map((s, i) => (
            <Text key={i} style={styles.source} numberOfLines={1}>
              {i + 1}. {s.source || s.title}
            </Text>
          ))}
        </View>
      ) : null}
      {!message.error ? (
        <Pressable onPress={() => Clipboard.setStringAsync(message.content)} style={styles.copy}>
          <Text style={styles.copyText}>⧉ Copy</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  userWrap: { alignItems: 'flex-end', marginVertical: 6 },
  userBubble: {
    maxWidth: '84%',
    backgroundColor: colors.userBubble,
    borderRadius: 22,
    borderBottomRightRadius: 6,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  userText: { fontSize: 16, color: colors.text, lineHeight: 23 },
  img: { width: 200, height: 200, borderRadius: 14, marginBottom: 8 },
  aiWrap: { marginVertical: 10, paddingRight: 8 },
  aiName: { fontSize: 13, fontWeight: '700', color: colors.textMuted, marginBottom: 6 },
  aiText: { fontSize: 16, color: colors.text, lineHeight: 25 },
  errorText: { fontSize: 15, color: colors.danger, lineHeight: 22 },
  sources: {
    marginTop: 10,
    backgroundColor: colors.chip,
    borderRadius: 14,
    padding: 12,
  },
  sourcesTitle: { fontSize: 13, fontWeight: '700', color: colors.textMuted, marginBottom: 4 },
  source: { fontSize: 13, color: colors.textMuted, marginTop: 2 },
  copy: { marginTop: 8, alignSelf: 'flex-start' },
  copyText: { fontSize: 13, color: colors.textFaint, fontWeight: '600' },
});
