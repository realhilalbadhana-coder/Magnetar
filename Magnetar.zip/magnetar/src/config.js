// ============================================================
// MAGNETAR - Model configuration
// "name" = jo UI mein dikhega | "modelId" = jo API ko call hoga
// ============================================================

export const PROVIDERS = {
  openrouter: {
    id: 'openrouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    keyName: 'openrouter_key',
    label: 'OpenRouter API Key',
    hint: 'sk-or-v1-...',
  },
  groq: {
    id: 'groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    keyName: 'groq_key',
    label: 'Groq API Key (Chat)',
    hint: 'gsk_...',
  },
  groqVoice: {
    id: 'groqVoice',
    baseUrl: 'https://api.groq.com/openai/v1',
    keyName: 'groq_voice_key',
    label: 'Groq API Key (Voice)',
    hint: 'gsk_... (Whisper ke liye alag key)',
  },
};

export const MODELS = [
  {
    id: 'gemini-reasoning',
    name: 'Gemini Reasoning',
    tagline: 'Deep thinking & analysis',
    provider: 'openrouter',
    modelId: 'google/gemma-4-31b-it:free',
  },
  {
    id: 'claude-opus',
    name: 'Claude Opus',
    tagline: 'Most capable, complex tasks',
    provider: 'openrouter',
    modelId: 'space-bunny-alpha:free',
  },
  {
    id: 'claude-sonnet-5',
    name: 'Claude Sonnet 5',
    tagline: 'Balanced speed & quality',
    provider: 'openrouter',
    modelId: 'moonshot/kimi-k2.5:free',
  },
  {
    id: 'gpt-6-sol',
    name: 'GPT-6 Sol',
    tagline: 'Reasoning with adjustable depth',
    provider: 'groq',
    modelId: 'qwen/qwen3.8-27b',
    reasoningLevels: ['low', 'medium', 'high'],
    defaultReasoning: 'medium',
  },
  {
    id: 'gpt-5-5',
    name: 'GPT-5.5',
    tagline: 'Instant replies',
    provider: 'groq',
    modelId: 'llama-3.1-8b-instant',
  },
  {
    id: 'gpt-6-luna',
    name: 'GPT-6 Luna',
    tagline: 'Versatile all-rounder',
    provider: 'groq',
    modelId: 'llama-3.3-70b-versatile',
  },
];

export const AUTO_MODEL_ID = 'gpt-6-luna';

export const VOICE_MODEL = 'openai/whisper-large-v3-turbo';

// Pollinations (vision) - OpenAI compatible endpoint
export const VISION = {
  url: 'https://gen.pollinations.ai/v1/chat/completions',
  model: 'openai',
};

export const SYSTEM_PROMPT =
  'You are Magnetar, a helpful, friendly and accurate AI assistant. ' +
  'Reply in the same language the user writes in (Hindi/Hinglish/English/Urdu). ' +
  'Be clear and concise. Use markdown-style lists and **bold** when it helps.';

export function getModel(id) {
  return MODELS.find((m) => m.id === id) || MODELS.find((m) => m.id === AUTO_MODEL_ID);
}
