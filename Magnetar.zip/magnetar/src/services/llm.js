import { PROVIDERS, getModel, SYSTEM_PROMPT } from '../config';
import { getKey } from './storage';

// Chat history ko API format mein convert karo
function toApiMessages(messages, extraSystem) {
  const sys = extraSystem ? SYSTEM_PROMPT + '\n\n' + extraSystem : SYSTEM_PROMPT;
  const out = [{ role: 'system', content: sys }];
  for (const m of messages) {
    if (m.role === 'user' || m.role === 'assistant') {
      if (m.content) out.push({ role: m.role, content: m.content });
    }
  }
  return out;
}

// Reasoning models kabhi <think>...</think> return karte hain - saaf karo
function cleanReply(text) {
  return (text || '')
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .replace(/^\s+/, '')
    .trim();
}

export async function askModel({ modelId, messages, reasoning, extraSystem, signal }) {
  const model = getModel(modelId);
  const provider = PROVIDERS[model.provider];
  const key = await getKey(provider.keyName);

  if (!key) {
    throw new Error(
      `${provider.label} set nahi hai. Menu → Settings mein jaake key paste karo.`
    );
  }

  const body = {
    model: model.modelId,
    messages: toApiMessages(messages, extraSystem),
    temperature: 0.7,
    max_tokens: 2048,
  };

  // GPT-6 Sol (Groq Qwen) ke liye low/medium/high reasoning
  if (model.reasoningLevels) {
    body.reasoning_effort = reasoning || model.defaultReasoning || 'medium';
  }

  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${key}`,
  };
  if (model.provider === 'openrouter') {
    headers['HTTP-Referer'] = 'https://magnetar.app';
    headers['X-Title'] = 'Magnetar';
  }

  const res = await fetch(`${provider.baseUrl}/chat/completions`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal,
  });

  const raw = await res.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`Server ne galat response diya (HTTP ${res.status})`);
  }

  if (!res.ok) {
    const msg = data?.error?.message || data?.message || `HTTP ${res.status}`;
    throw new Error(friendlyError(res.status, msg));
  }

  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error('Model ne khaali jawab diya. Dobara try karo.');
  return cleanReply(content);
}

function friendlyError(status, msg) {
  if (status === 401) return 'API key galat hai ya expire ho gayi. Settings mein check karo.';
  if (status === 402) return 'Credits khatam ho gaye hain.';
  if (status === 404) return `Model nahi mila: ${msg}`;
  if (status === 429) return 'Rate limit lag gayi. Thodi der baad try karo ya dusra model chuno.';
  if (status >= 500) return 'Provider ka server abhi down hai. Dusra model try karo.';
  return msg;
}

// Chat ka chhota title banane ke liye (fast model)
export function makeTitle(text) {
  const t = (text || '').replace(/\s+/g, ' ').trim();
  return t.length > 32 ? t.slice(0, 32).trim() + '…' : t || 'New chat';
}
