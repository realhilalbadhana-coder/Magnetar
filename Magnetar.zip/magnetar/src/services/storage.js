import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ---- API keys (secure storage) ----
export async function saveKey(name, value) {
  const v = (value || '').trim();
  if (!v) {
    await SecureStore.deleteItemAsync(name);
    return;
  }
  await SecureStore.setItemAsync(name, v);
}

export async function getKey(name) {
  try {
    return (await SecureStore.getItemAsync(name)) || '';
  } catch {
    return '';
  }
}

// ---- Chats ----
const CHATS_KEY = 'magnetar_chats_v1';

export async function loadChats() {
  try {
    const raw = await AsyncStorage.getItem(CHATS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export async function saveChats(chats) {
  try {
    await AsyncStorage.setItem(CHATS_KEY, JSON.stringify(chats));
  } catch {}
}

// ---- Settings ----
const SETTINGS_KEY = 'magnetar_settings_v1';

export async function loadSettings() {
  try {
    const raw = await AsyncStorage.getItem(SETTINGS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export async function saveSettings(s) {
  try {
    await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {}
}
