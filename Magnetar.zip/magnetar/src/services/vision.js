import * as FileSystem from 'expo-file-system';
import { VISION } from '../config';

// Image ko base64 mein badal ke Pollinations vision model se analyze karo
export async function analyzeImage(uri, prompt) {
  const base64 = await FileSystem.readAsStringAsync(uri, {
    encoding: FileSystem.EncodingType.Base64,
  });

  const ext = (uri.split('.').pop() || 'jpeg').toLowerCase().split('?')[0];
  const mime = ext === 'png' ? 'png' : ext === 'webp' ? 'webp' : 'jpeg';

  const res = await fetch(VISION.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: VISION.model,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt || 'Is image mein kya hai? Detail mein batao.' },
            { type: 'image_url', image_url: { url: `data:image/${mime};base64,${base64}` } },
          ],
        },
      ],
      temperature: 0.3,
    }),
  });

  const raw = await res.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`Vision server error (HTTP ${res.status})`);
  }
  if (!res.ok) throw new Error(data?.error?.message || data?.message || `Vision failed (HTTP ${res.status})`);

  // NOTE: choices ek ARRAY hai -> choices[0]
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('Vision model ne kuch return nahi kiya.');
  return text.trim();
}
