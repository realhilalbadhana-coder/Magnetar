import { Audio } from 'expo-av';
import { PROVIDERS, VOICE_MODEL } from '../config';
import { getKey } from './storage';

let recording = null;

export async function startRecording() {
  const perm = await Audio.requestPermissionsAsync();
  if (!perm.granted) throw new Error('Microphone permission chahiye.');

  await Audio.setAudioModeAsync({
    allowsRecordingIOS: true,
    playsInSilentModeIOS: true,
  });

  const { recording: rec } = await Audio.Recording.createAsync(
    Audio.RecordingOptionsPresets.HIGH_QUALITY
  );
  recording = rec;
}

export async function cancelRecording() {
  try {
    if (recording) await recording.stopAndUnloadAsync();
  } catch {}
  recording = null;
}

export async function stopAndTranscribe() {
  if (!recording) throw new Error('Recording chalu nahi hai.');
  const rec = recording;
  recording = null;

  await rec.stopAndUnloadAsync();
  await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
  const uri = rec.getURI();
  if (!uri) throw new Error('Audio file nahi mili.');

  const key = await getKey(PROVIDERS.groqVoice.keyName);
  if (!key) {
    throw new Error('Groq Voice key set nahi hai. Menu → Settings mein daalo.');
  }

  const form = new FormData();
  form.append('file', { uri, name: 'voice.m4a', type: 'audio/m4a' });
  form.append('model', VOICE_MODEL);
  form.append('response_format', 'json');

  const res = await fetch(`${PROVIDERS.groqVoice.baseUrl}/audio/transcriptions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}` },
    body: form,
  });

  const raw = await res.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`Voice server error (HTTP ${res.status})`);
  }
  if (!res.ok) throw new Error(data?.error?.message || `Voice failed (HTTP ${res.status})`);
  return (data.text || '').trim();
}
