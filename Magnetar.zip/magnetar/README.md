# Magnetar

Multi-model AI chat app (Expo + React Native). Copilot-style UI.

## Models (UI name -> real model)
| UI name | Provider | Real model |
|---|---|---|
| Gemini Reasoning | OpenRouter | google/gemma-4-31b-it:free |
| Claude Opus | OpenRouter | space-bunny-alpha:free |
| Claude Sonnet 5 | OpenRouter | moonshot/kimi-k2.5:free |
| GPT-6 Sol (low/medium/high) | Groq | qwen/qwen3.8-27b |
| GPT-5.5 | Groq | llama-3.1-8b-instant |
| GPT-6 Luna | Groq | llama-3.3-70b-versatile |

Voice -> Groq `openai/whisper-large-v3-turbo` | Vision -> Pollinations | Web search -> Google News RSS

Model IDs badalne hon to sirf `src/config.js` edit karo.

## API keys
Keys code mein NAHI hain. App kholo -> Menu -> Settings -> keys paste karo (phone ke secure storage mein save hoti hain).

## APK banane ke 2 tareeke

### 1) GitHub Actions (sabse easy, koi account nahi chahiye)
1. Naya GitHub repo banao aur is folder ka sara code push karo (`main` branch)
2. Repo -> **Actions** tab -> **Build Magnetar APK** -> **Run workflow**
3. ~10-15 min baad run kholo -> **Artifacts** -> `Magnetar-APK` download karo -> zip mein `app-release.apk`

### 2) EAS Cloud Build
```
npm install -g eas-cli
npm install --legacy-peer-deps
eas login
eas build -p android --profile preview
```

## Local test
```
npm install --legacy-peer-deps
npx expo start
```
